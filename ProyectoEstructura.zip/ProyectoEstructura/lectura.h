#ifndef lectura_h
#define lectura_h

char * _strdup (const char *s);
const char *get_csv_field (char * tmp, int i);

#endif // lectura_h

